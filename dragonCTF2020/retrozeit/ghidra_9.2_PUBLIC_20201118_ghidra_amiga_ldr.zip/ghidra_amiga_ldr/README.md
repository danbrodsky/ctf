# ghidra_amiga_ldr
Amiga hunks loader
