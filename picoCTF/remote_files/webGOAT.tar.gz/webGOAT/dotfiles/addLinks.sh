rm -rf ~/.tmux
rm ~/.tmux.conf
rm -rf ~/.vim
rm ~/.vimrc
rm -rf ~/.vim_runtime
rm -rf ~/.zsh
rm ~/.zshrc
rm ~/.config/termite/config
rm ~/.config/i3/config
rm ~/.config/terminator/config

ln -s ~/dotfiles/.tmux ~
ln -s ~/dotfiles/.tmux.conf ~
ln -s ~/dotfiles/.vim ~
ln -s ~/dotfiles/.vimrc ~
ln -s ~/dotfiles/.vim_runtime ~
ln -s ~/dotfiles/.zsh ~
ln -s ~/dotfiles/.zshrc ~
ln -s ~/dotfiles/termite-config ~/.config/termite/config
ln -s ~/dotfiles/i3-config ~/.config/i3/config
ln -s ~/dotfiles/terminator-config ~/.config/terminator/config
