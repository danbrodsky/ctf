#!/bin/bash

apt-get install chromium zsh tmux rofi i3 terminator
